import React from 'react';
import Pagination from '../component/paginition';
export default function ListView() {
  return <div>
    <h1>列表视图</h1>
    <Pagination />
  </div>;
}
