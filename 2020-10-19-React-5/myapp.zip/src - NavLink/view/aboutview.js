import React from 'react';
export default function AboutView() {
  return <h1>关于视图</h1>;
}
