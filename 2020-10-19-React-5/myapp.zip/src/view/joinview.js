import React from 'react';
export default function JoinView(props) {
  console.log(props);
  const {history} = props;
  const {go,goBack,goForward,push,length} = history;
  return <div>
    <h1>加入视图-{length}</h1>
    <button onClick={()=>{
      goBack();
    }}>返回</button>
    <button onClick={()=>{
      goForward();
    }}>前进</button>
    <input 
      type="text" 
      onBlur={(target)=>{
        go(target.value)
      }}
    />
    <br />
    <button onClick={()=>{
        //window.location.href = "/about";
        push("/about",{context:"哈哈"});
    }}>关于</button>
  </div>;
}
