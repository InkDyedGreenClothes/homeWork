import React from 'react';
export default function JoinView(props) {
  console.log(props);
  return <div>
    <h1>加入视图</h1>
      </div>;
}
