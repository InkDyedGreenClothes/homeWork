import React from 'react';
export default function AboutView(props) {
  console.log(props);
  return <h1>关于视图</h1>;
}
