import React from 'react';
export default function View404() {
  console.log(1233131313);
  return <h1>页面飞走了</h1>;
}
