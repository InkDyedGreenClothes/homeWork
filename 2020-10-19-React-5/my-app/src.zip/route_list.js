import React from 'react';
import { Redirect } from 'react-router-dom';
import View404 from './view/404view';
import AboutView from './view/aboutview';
import IndexView from './view/indexview';
import JoinView from './view/joinview';
import ListView from './view/list';

const types = ["all", "good", "share", "ask"]

const nav_list = [
  {
    title: "全部",
    to: "/",
    exact: false,
    isActive(pathname) {
      console.log(pathname.substring(0,4));
      return pathname === "/" || pathname === "/home" || pathname == "/all" || pathname.substring(0,4) == "/all";
    }
  }, {
    title: "精华",
    to: "/good",
    exact: false
  }, {
    title: "分享",
    to: "/ask",
    exact: false
  }, {
    title: "问答",
    to: "/share",
    exact: false
  }
];


const route_list = [
  {
    path: ["/", "/home", "/home/all", "/:type", "/home/:type", "/:type/:page", "/home/:type/:page"],
    exact: true,
    render(props) {
      return <IndexView {...props} />
    }
  }, {
    path: "/good",
    exact: true,
    render(props) {
      return <AboutView {...props} />
    }
  }, {
    path: "/ask",
    exact: true,
    render(props) {
      return <JoinView {...props} />
    }
  }, {
    path: ["/share", "/share/:type", "/share/:type/:page"],
    exact: true,
    render(props) {
      const { type = "all", page = "1" } = props.match.params;

      if (types.includes(type)
        && page > 0
        && parseInt(page) + "" === page) {
        return <ListView {...props} />
      }
      return <Redirect to="/undefined" />
    }
  }, {
    path: "",
    render(props) {
      return <View404 {...props} />
    }
  }
];

export { route_list, nav_list }