import React from 'react';
import List from '../component/list';
import Pagination from '../component/paginition';
export default function ListView() {
  return <div>
    <List />
    <Pagination />
  </div>;
}
