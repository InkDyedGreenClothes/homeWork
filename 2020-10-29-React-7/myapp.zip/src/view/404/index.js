import React from "react";

function UndefinedPage() {
    return <h1>404</h1>
}

export default UndefinedPage;