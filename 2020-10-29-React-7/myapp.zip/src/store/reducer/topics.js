function topics(topics=[],action) {
    return topics;
}

export default topics;