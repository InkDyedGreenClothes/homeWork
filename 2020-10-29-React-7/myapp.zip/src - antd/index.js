import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
/*
  React 严格模式
*/
ReactDOM.render(
    <App />,
  document.getElementById('root')
);
