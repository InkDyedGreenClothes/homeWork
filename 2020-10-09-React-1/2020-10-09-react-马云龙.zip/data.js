
const data = [
    {
        name: "家人",
        children:[`爸爸`, `妈妈`]
    },{
        name: "朋友",
        children:[`张三`, `李四`, `王五`]
    },{
        name:"客户",
        children:[`阿里`, `腾讯`, `头条`]
    }
];

export default data;