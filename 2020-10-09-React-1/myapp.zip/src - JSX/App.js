import React,{Component} from "react";
// class App extends React.Component {}
class App extends Component {
  render(){
    return <div>这是内容</div>
  }
}

export default App;