import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
// 调用组件可以通过 JSX 的形式进行调用
ReactDOM.render(
  <App />,
  document.querySelector("#root")
);
