const data = [
    {
        name: "React",
        children:[`Component`, `Hooks`]
    },{
        name: "Router",
        children:[`Browsers`, `Hash`, `NavLink`]
    },{
        name:"Redux",
        children:[`reducer`, `action`, `dispatch`]
    }
];

export default data;