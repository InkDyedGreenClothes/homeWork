
const KoaBody = require('koa-body');

module.exports = function getBody() {
    return KoaBody()
}
