import './css/css.css'

let btn = document.querySelector('#btn');
btn.onclick = function () {
  console.log('开课吧~马云龙');
}