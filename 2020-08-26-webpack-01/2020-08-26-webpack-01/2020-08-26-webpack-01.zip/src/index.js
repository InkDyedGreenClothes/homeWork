import fn from './fn.js'
import logo from './images/logo.png';
import css from './css/css.css';

console.log('fn', fn);
