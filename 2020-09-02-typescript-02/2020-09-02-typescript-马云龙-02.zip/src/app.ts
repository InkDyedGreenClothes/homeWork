import Kkb from './Kkb/Kkb';

const app = new Kkb({
    port: 8888
});

app.start();