
export default async ctx => {
    ctx.body = 'hello kkb';
}