console.log("b.js");
define({
    info:"b.js"
})