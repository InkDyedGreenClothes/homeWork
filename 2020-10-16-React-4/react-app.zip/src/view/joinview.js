import React from 'react';
export default function JoinView() {
  return <h1>加入视图</h1>;
}
